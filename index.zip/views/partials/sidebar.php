<?php
$current_page = basename($_SERVER['PHP_SELF']);
$current_dir  = basename(dirname($_SERVER['PHP_SELF']));

// Hitung pesanan "Dibayar" yang belum diproses (siap diproses sales)
$jumlah_pesanan_baru = 0;
if (isset($_SESSION['role']) && $_SESSION['role'] == 'sales') {
    require_once __DIR__ . '/../../config/koneksi.php';
    $q_notif = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM pesanan WHERE status = 'Dibayar'");
    $jumlah_pesanan_baru = mysqli_fetch_assoc($q_notif)['total'] ?? 0;
}
?>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="sidebar-brand">
        <h4>🌸 GlowSkin</h4>
        <small>Skincare Sales System</small>
    </div>

    <div class="sidebar-user">
        <div class="user-avatar"><?= strtoupper(substr($_SESSION['nama_lengkap'], 0, 1)); ?></div>
        <div class="user-info">
            <div class="user-name"><?= $_SESSION['nama_lengkap']; ?></div>
            <div class="user-role"><?= ucfirst($_SESSION['role']); ?></div>
        </div>
    </div>

    <ul class="sidebar-menu">
        <li class="<?= $current_page == 'dashboard.php' ? 'active' : ''; ?>">
            <a href="/sistem_skincare/views/dashboard.php">🏠 Dashboard</a>
        </li>
        <li class="<?= $current_dir == 'barang' ? 'active' : ''; ?>">
            <a href="/sistem_skincare/views/barang/index.php">📦 Data Barang</a>
        </li>

        <?php if ($_SESSION['role'] == 'sales'): ?>
        <li class="<?= $current_dir == 'transaksi' ? 'active' : ''; ?>">
            <a href="/sistem_skincare/views/transaksi/kasir.php">🛒 Transaksi Baru</a>
        </li>
        <?php endif; ?>

        <?php if ($_SESSION['role'] == 'admin'): ?>
        <li class="<?= $current_dir == 'laporan' ? 'active' : ''; ?>">
            <a href="/sistem_skincare/views/laporan/index.php">📊 Laporan Penjualan</a>
        </li>
        <?php endif; ?>

        <!-- PESANAN MASUK DENGAN NOTIF BADGE -->
        <li class="<?= $current_dir == 'pesanan' ? 'active' : ''; ?>">
            <a href="/sistem_skincare/views/pesanan/index.php" style="display: flex; justify-content: space-between; align-items: center;">
                <span>📋 Pesanan Masuk</span>
                <?php if ($jumlah_pesanan_baru > 0): ?>
                    <span class="notif-badge"><?= $jumlah_pesanan_baru; ?></span>
                <?php endif; ?>
            </a>
        </li>

        <li class="<?= $current_dir == 'komisi' ? 'active' : ''; ?>">
            <a href="/sistem_skincare/views/komisi/index.php">💰 Data Komisi</a>
        </li>

        <?php if ($_SESSION['role'] == 'admin'): ?>
        <li class="<?= $current_dir == 'user' ? 'active' : ''; ?>">
            <a href="/sistem_skincare/views/user/index.php">👥 Kelola User</a>
        </li>
        <?php endif; ?>

        <li>
            <a href="/sistem_skincare/public/katalog.php" target="_blank">🌐 Lihat Katalog</a>
        </li>
    </ul>

    <div class="sidebar-footer">
        <a href="/sistem_skincare/views/auth/logout.php" class="btn btn-light btn-sm w-100">🚪 Logout</a>
    </div>
</div>

<!-- CSS SIDEBAR -->
<style>
    body {
        margin: 0;
        padding: 0;
        background-color: #fce4ec;
        font-family: 'Segoe UI', sans-serif;
    }
    
    .sidebar {
        position: fixed;
        left: 0;
        top: 0;
        width: 260px;
        height: 100vh;
        background: linear-gradient(180deg, #d81b60 0%, #ad1457 100%);
        color: white;
        overflow-y: auto;
        box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        z-index: 100;
    }
    
    .sidebar-brand {
        padding: 25px 20px 15px;
        text-align: center;
        border-bottom: 1px solid rgba(255,255,255,0.15);
    }
    .sidebar-brand h4 { margin: 0; font-weight: bold; }
    .sidebar-brand small { opacity: 0.8; font-size: 0.75rem; }
    
    .sidebar-user {
        padding: 20px;
        display: flex;
        align-items: center;
        gap: 12px;
        border-bottom: 1px solid rgba(255,255,255,0.15);
    }
    
    .user-avatar {
        width: 45px;
        height: 45px;
        border-radius: 50%;
        background: rgba(255,255,255,0.2);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        font-size: 1.2rem;
    }
    .user-name { font-weight: 600; font-size: 0.9rem; }
    .user-role { font-size: 0.75rem; opacity: 0.8; }
    
    .sidebar-menu {
        list-style: none;
        padding: 15px 10px;
        margin: 0;
    }
    .sidebar-menu li { margin-bottom: 5px; }
    .sidebar-menu li a {
        display: block;
        padding: 12px 18px;
        color: rgba(255,255,255,0.85);
        text-decoration: none;
        border-radius: 10px;
        transition: all 0.3s;
        font-size: 0.9rem;
    }
    .sidebar-menu li a:hover {
        background: rgba(255,255,255,0.15);
        color: white;
        padding-left: 25px;
    }
    .sidebar-menu li.active a {
        background: rgba(255,255,255,0.25);
        color: white;
        font-weight: 600;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    
    /* NOTIF BADGE MERAH */
    .notif-badge {
        background: #ff1744;
        color: white;
        font-size: 0.7rem;
        font-weight: 700;
        padding: 3px 8px;
        border-radius: 12px;
        min-width: 22px;
        text-align: center;
        box-shadow: 0 2px 6px rgba(255,23,68,0.5);
        animation: pulse-notif 1.5s infinite;
    }
    
    @keyframes pulse-notif {
        0% { transform: scale(1); box-shadow: 0 2px 6px rgba(255,23,68,0.5); }
        50% { transform: scale(1.1); box-shadow: 0 2px 12px rgba(255,23,68,0.8); }
        100% { transform: scale(1); box-shadow: 0 2px 6px rgba(255,23,68,0.5); }
    }
    
    .sidebar-footer {
        padding: 20px;
        border-top: 1px solid rgba(255,255,255,0.15);
    }
    
    .main-content {
        margin-left: 260px;
        padding: 30px;
        min-height: 100vh;
    }
    
    @media print {
        .sidebar, .no-print { display: none !important; }
        .main-content { margin-left: 0 !important; }
    }
</style>