<?php
require_once '../../config/koneksi.php';
require_once '../../config/helper.php';

if (isset($_SESSION['id_user'])) {
    header("Location: ../sistem_skincare/views/dashboard.php");
    exit;
}

$error = '';
if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($koneksi, $query);

if (!$result) {
    die("Query login gagal: " . mysqli_error($koneksi));
}

    if (mysqli_num_rows($result) === 1) {
        $user = mysqli_fetch_assoc($result);
        
        if ($password === $user['password']) {
            $_SESSION['id_user']       = $user['id_user'];
            $_SESSION['nama_lengkap']  = $user['nama_lengkap'];
            $_SESSION['role']          = $user['role'];
            $_SESSION['komisi_persen'] = $user['komisi_persen'];
            
            header("Location: ../dashboard.php");
            exit;
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Username tidak ditemukan!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login - GlowSkin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #fce4ec, #f8bbd0); height: 100vh; display: flex; align-items: center; }
        .card-login { border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card card-login p-4">
                <h3 class="text-center mb-2" style="color: #d81b60;">🌸 GlowSkin</h3>
                <p class="text-center text-muted small mb-4">Sistem Penjualan & Komisi Sales</p>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?= $error ?></div>
                <?php endif; ?>
                <form method="POST">
                    <div class="mb-3">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control" required autofocus>
                    </div>
                    <div class="mb-3">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <button type="submit" name="login" class="btn w-100 text-white" style="background-color: #d81b60;">Login</button>
                </form>
                <hr>
                <small class="text-muted text-center d-block">
                    Dummy: <b>admin</b>/admin123 | <b>budi</b>/sales123
                </small>
            </div>
        </div>
    </div>
</div>
</body>
</html>